//
//  FullView.h
//  网络视频播放(AVPlayer)
//
//  Created by apple on 15/8/26.
//  Copyright (c) 2015年 FMG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FullView : UIView

@end
