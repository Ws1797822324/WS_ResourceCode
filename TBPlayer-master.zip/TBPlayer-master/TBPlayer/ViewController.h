//
//  ViewController.h
//  TBPlayer
//
//  Created by qianjianeng on 16/1/31.
//  Copyright © 2016年 SF. All rights reserved.
//
//// github地址：https://github.com/suifengqjn/TBPlayer
#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

